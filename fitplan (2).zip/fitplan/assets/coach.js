/* Vai trò: Huấn luyện viên (coach) — Học viên, Duyệt kế hoạch, Template */
const mlist=()=>{const r=D.mem.filter(m=>m.name.toLowerCase().includes(q.toLowerCase()));return r.length?`<div class=grid>${r.map(m=>card(m.name,`<p>${m.goal} — ${m.n} buổi/tuần</p><br>`+bt('Xem chi tiết','view',m.id))).join('')}</div>`:bx('Không tìm thấy học viên nào.')};
const c3=(c,m)=>{if(c.s=='run'||!c.s)return 'Đang xử lý...';if(c.s=='nodata')return bx('Không đủ dữ liệu để tóm tắt (cần ít nhất 3 buổi).',bt('Thử lại','re3'));if(c.s=='unsure')return bx('AI chưa chắc chắn về tóm tắt này.',bt('Xem log gốc','raw','','gh')+bt('Thử lại','re3')+bt('Báo cáo','rep','','gh'));const g=c.r>=.7;return `<div class=ai>${bd(g?'ok':'wa',g?'Tốt':'Cần chú ý')} Hoàn thành ${Math.round(c.r*100)}% trong ${c.n} buổi gần nhất (mục tiêu ${m.n} buổi/tuần).</div>`};
const modal=()=>{const m=D.mem.find(x=>x.id==mod),L=D.ml[m.id],c=ai.c&&ai.c.id==m.id?ai.c:{};return `<div class=ov><div class=mb><button class=x data-a=close>×</button><h2>${m.name}</h2><p class=mu>${m.goal} — ${m.n} buổi/tuần</p><h3 id=lg>Lịch sử log tập</h3>${L.length?`<ul>${L.map((o,i)=>`<li>${dt(i*2).slice(5)} — ${o?'Xong':'Bỏ dở'}`).join('')}</ul>`:bx('Chưa có log nào.')}<h3>Tóm tắt AI</h3>${c3(c,m)}</div></div>`};

Object.assign(VIEW,{
members:()=>h('Danh sách học viên','Xem thông tin và tóm tắt tập luyện')+bx(`Có <b>${D.plans.filter(x=>x.st=='pending').length}</b> kế hoạch chờ duyệt.`,bt('Đi duyệt','go','review','pr'))+`<label>Tìm học viên theo tên<input id=q value="${esc(q)}"></label><div id=lst>${mlist()}</div>`,
review:()=>h('Duyệt kế hoạch tập','Phản hồi kế hoạch do học viên gửi')+(D.plans.length?`<div class=grid>${D.plans.map(p=>card(p.m+' — '+p.t,`<ul>${p.it.map(i=>`<li>${i}`).join('')}</ul><br>${bd(...ST[p.st])}${p.note?`<p>Đã yêu cầu sửa: ${esc(p.note)}</p>`:''}`+(p.st=='pending'?`<br><br>${bt('Chấp nhận','ac2',p.id,'ok')} ${bt('Từ chối','rj',p.id,'er')} ${bt('Yêu cầu sửa','ask',p.id,'gh')}`+(rev.i==p.id?`<form data-f=fb>${fld({n:'note',l:'Nhận xét cho học viên',t:'area'},'',er.fb)}<button class="btn pr">Gửi yêu cầu sửa</button> ${bt('Huỷ','cx','','gh')}</form>`:''):''))).join('')}</div>`:bx('Chưa có kế hoạch nào cần duyệt.')),
tpl:()=>h('Quản lý template bài tập','Thêm, sửa, xoá bài tập mẫu dùng chung')+mgr('tpl','template',[{n:'name',l:'Tên bài tập',req:1},{n:'group',l:'Nhóm cơ'},{n:'sets',l:'Số hiệp',t:'number',req:1,min:1},{n:'reps',l:'Số lần',t:'number',req:1,min:1}],[['Tên',x=>x.name],['Nhóm cơ',x=>x.group],['Hiệp x lần',x=>x.sets+' x '+x.reps]],{empty:'Chưa có template nào.'})});

function ai3(id){ai.c={id,s:'run'};draw();setTimeout(()=>{const L=D.ml[id],r=L.filter(x=>x).length/(L.length||1);ai.c={id,n:L.length,r,s:L.length<3?'nodata':r>=.4&&r<=.6?'unsure':'ok'};if(mod==id)draw()},600)}
const sst=(i,s)=>{D.plans.find(p=>p.id==i).st=s;toast('Đã cập nhật kế hoạch');draw()};

Object.assign(A,{
view:i=>{mod=+i;ai3(+i)},close:()=>{mod=null;draw()},re3:()=>ai3(mod),raw:()=>$('#lg').scrollIntoView(),rep:()=>toast('Đã gửi báo cáo'),
ac2:i=>sst(i,'completed'),rj:i=>sst(i,'rejected'),ask:i=>{rev={i:+i};er.fb='';draw()},cx:()=>{rev={};draw()}});
Object.assign(F,{
fb:d=>{if(!d.note.trim()){er.fb='Nhận xét không được để trống.';return draw()}D.plans.find(p=>p.id==rev.i).note=d.note.trim();rev={};er.fb='';toast('Đã gửi yêu cầu sửa');draw()}});
document.addEventListener('input',e=>{if(e.target.id=='q'){q=e.target.value;$('#lst').innerHTML=mlist()}});
